package Main;



import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import Admin.adminLogin;

public class firstScreen extends JFrame{
	private static final long serialVersionUID = 1L;
	JButton b1,b2,b3,b4;
	
	public firstScreen() {
		//b1 = new JButton("<html><body><center>상영 중<br> <br>영화</center></body></html>");
		b1 = new JButton("");
		b1.setIcon(new ImageIcon("d:/image/1.jpg"));
		b1.setBounds(45, 652, 142, 274);
		
		b2 = new JButton("<html><body><center>영화표<br> <br>출력</center></body></html>");
		b2.setBounds(325, 652, 142, 272);
		
		b3 = new JButton("음식 주문");
		b3.setBounds(574, 652, 153, 272);
		
		b4 = new JButton("관리자모드");
		b4.setBounds(12, 10, 130, 54);
		
		ImageIcon img = new ImageIcon("d:/image/11.jpg");
		Image imgg = img.getImage();
		Image changeImg = imgg.getScaledInstance(300, 300, DO_NOTHING_ON_CLOSE);
		img = new ImageIcon(changeImg);
		JLabel imageLabel = new JLabel(img);
		imageLabel.setIcon(img);
		imageLabel.setBounds(90, 70, 300, 300);
		

		
		getContentPane().add(b1);getContentPane().add(b2);getContentPane().add(b3);getContentPane().add(b4);
		getContentPane().add(imageLabel);
		
		Font font = new Font("나눔바른고딕 보통", Font.PLAIN, 13);
		Font font1 = new Font("나눔바른고딕 보통", Font.PLAIN, 10);
		
		b1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new MovieRe();
				setVisible(false);
			}
		});
		
		b2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new KeypadGUI();
				setVisible(false);
			}
		});
		
		b3.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				new FoodUiNew();
				setVisible(false);
			}
		});
		
		b4.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				new adminLogin(firstScreen.this);
			}
		});

		b1.setFont(font);
		b2.setFont(font);
		b3.setFont(font);
		b4.setFont(font1);
		getContentPane().setLayout(null);
		setSize(800, 1000);

		setResizable(false);
		setVisible(true);

	
		
		b1.setFont(font);
		b2.setFont(font);
		b3.setFont(font);
		b4.setFont(font1);
		getContentPane().setLayout(null);		
		setSize(800,1000);       
										
		setResizable(false);	
		setVisible(true);		
		
	}
	
	
	public static void main(String[] args) {
		new firstScreen();
	}


}
