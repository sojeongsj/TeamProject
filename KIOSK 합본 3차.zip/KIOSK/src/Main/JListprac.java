package Main;

import java.sql.SQLException;
import java.util.List;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import kioskDAO.FoodDAO;
import kioskDTO.FoodDTO;

public class JListprac {
	JTable jt;
	DefaultTableModel dm;
	
	public static void main(String[] args) throws SQLException {
		FoodDAO fdo = new FoodDAO();
		List<FoodDTO> list= fdo.getFoodsByCategory("popcorn");
		for(FoodDTO fdto : list) {
			System.out.println(fdto);
			}
	}
	

		
		
		
		
	
	
}
