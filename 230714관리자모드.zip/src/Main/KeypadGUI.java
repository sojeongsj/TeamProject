package Main;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class KeypadGUI extends JFrame implements ActionListener {
    private JTextField textField;

    public KeypadGUI() {
        setTitle("Keypad");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // 텍스트 필드 생성
        textField = new JTextField();
        textField.setEditable(false);
        textField.setPreferredSize(new Dimension(200, 50));
        textField.setFont(new Font("Arial", Font.PLAIN, 20));
        add(textField, BorderLayout.NORTH);

        // 버튼 패널 생성
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridBagLayout()); // GridBagLayout으로 변경

        // GridBagConstrains 생성
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.NONE; // 컴포넌트가 채워질 수 있는 최대 크기로 설정
        gbc.insets = new Insets(5, 5, 5, 5); // 컴포넌트 간의 간격 설정

        // 버튼 추가
        for (int i = 1; i <= 9; i++) {
            JButton button = new JButton(String.valueOf(i));
            button.addActionListener(this);
            gbc.gridx = (i - 1) % 3; // 열 위치 설정
            gbc.gridy = (i - 1) / 3; // 행 위치 설정
            button.setPreferredSize(new Dimension(200, 100));
            buttonPanel.add(button, gbc);
        }

        // Clear 버튼 추가
        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(this);
        gbc.gridx = 0; // 열 위치 설정
        gbc.gridy = 3; // 행 위치 설정
        clearButton.setPreferredSize(new Dimension(200, 100));
        buttonPanel.add(clearButton, gbc);

        // 0 버튼 추가
        JButton zeroButton = new JButton("0");
        zeroButton.addActionListener(this);
        gbc.gridx = 1; // 열 위치 설정
        gbc.gridy = 3; // 행 위치 설정
        zeroButton.setPreferredSize(new Dimension(200, 100));
        buttonPanel.add(zeroButton, gbc);

        // Enter 버튼 추가
        JButton enterButton = new JButton("Enter");
        enterButton.addActionListener(this);
        gbc.gridx = 2; // 열 위치 설정
        gbc.gridy = 3; // 행 위치 설정
        enterButton.setPreferredSize(new Dimension(200, 100));
        buttonPanel.add(enterButton, gbc);
        
          JButton backButton = new JButton("뒤로가기");
          backButton.addActionListener(this);
          gbc.gridx = 3; // 열 위치 설정
          gbc.gridy = 4; // 행 위치 설정
          backButton.setPreferredSize(new Dimension(100, 50));
          buttonPanel.add(backButton);
          
          backButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new firstScreen();
				setVisible(false);
			}
		});

        add(buttonPanel, BorderLayout.CENTER);

        // Enter 키 이벤트 처리
        textField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    handleEnterKey();
                }
            }
        });

        pack();
        setSize(800, 1000);
        setVisible(true);
    }

    private void handleEnterKey() {
        String text = textField.getText().replaceAll("-", "");
        System.out.println("입력된 값: " + text);
        textField.setText("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String actionCommand = e.getActionCommand();
        if (actionCommand.equals("Clear")) {
            textField.setText("");
        } else if (actionCommand.equals("Enter")) {
            handleEnterKey();
        } else {
            if (textField.getText().replaceAll("-", "").length() < 16) {
                textField.setText(textField.getText() + actionCommand);
                if (textField.getText().replaceAll("-", "").length() % 4 == 0 && textField.getText().length() != 16) {
                    if (textField.getText().length() != 19)
                        textField.setText(textField.getText() + "-");
                }
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new KeypadGUI();
            }
        });
    }
}









