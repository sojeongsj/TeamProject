package Main;

import java.util.ArrayList;
import java.util.List;

import theaterDAO.FoodBuyDAO;
import theaterDTO.FoodBuyDTO;

public class main12312 {
	public static void main(String[] args) {
		FoodBuyDAO fbd = new FoodBuyDAO();
		List<FoodBuyDTO> carts = new ArrayList<>();
		carts.add(new FoodBuyDTO(0,"snack", "떡볶이", 6500, 3));
		int count = fbd.InsertCart(carts);
		System.out.println(count);
		
	}
}
