package Main;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.SQLException;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import theaterDAO.FoodDAO;
import theaterDTO.FoodDTO;


public class FoodUI2 extends JFrame {
    private JPanel panel;
    private JButton button1;
    private JButton button2;
    private JButton button3;
    private JButton button4;
    private JButton button5;
    private JList<Object> list;

    public FoodUI2() {
        panel = new JPanel();
        button1 = new JButton("팝콘");
        button1.setBounds(18, 22, 174, 68);
        button2 = new JButton("음료수");
        button2.setBounds(204, 22, 174, 68);
        button3 = new JButton("스낵");
        button3.setBounds(388, 22, 174, 68);
        button4 = new JButton("콤보");
        button4.setBounds(574, 22, 174, 68);
        button5 = new JButton("결제하기");
        button5.setBounds(574, 750, 174, 68);

        list = new JList<>();

        // 리스트 초기화 및 데이터 설정
        DefaultListModel<Object> listModel = new DefaultListModel<>();
        list.setModel(listModel);

        // 버튼 클릭 이벤트 처리
        button1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadDataFromDAO("popcorn");
            }
        });

        button2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadDataFromDAO("drink");
            }
        });

        button3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadDataFromDAO("snack");
            }
        });

        button4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadDataFromDAO("combo");
            }
        });

        JScrollPane scrollPane = new JScrollPane(list);
        scrollPane.setBounds(18, 200, 750, 500);

        JScrollPane cartPane = new JScrollPane();
        cartPane.setBounds(18, 720, 400, 200);

        getContentPane().add(panel);
        panel.setLayout(null);
        panel.add(button1);
        panel.add(button2);
        panel.add(button3);
        panel.add(button4);
        panel.add(scrollPane);
        panel.add(cartPane);
        panel.add(button5);

        setSize(800, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        loadDataFromDAO("popcorn"); // 처음 실행할 때 팝콘에 해당하는 목록만 보이도록 설정
    }

    // DAO에서 데이터를 가져와서 해당하는 목록의 리스트를 보이도록 설정
    private void loadDataFromDAO(String category) {
        DefaultListModel<Object> listModel = (DefaultListModel<Object>) list.getModel();
        listModel.clear();

        try {
            FoodDAO foodDAO = new FoodDAO();
            List<FoodDTO> foods = foodDAO.getFoodsByCategory(category);

            for (FoodDTO food : foods) {
            	for(int i = 0; i<foods.size() ; i++) {
            		File imageFile = new File("d:/image/P"+(1+i)+".jpg"); // 이미지 파일 경로 지정
            		ImageIcon icon = new ImageIcon(imageFile.getPath()); // 이미지 아이콘 생성
            		Image img = icon.getImage();
            		img = img.getScaledInstance(100, 100, DO_NOTHING_ON_CLOSE);
            		icon = new ImageIcon(img);
            		listModel.addElement(icon);
            	}
                listModel.addElement(food.getFoodName());
                listModel.addElement(String.valueOf(food.getFoodPrice()));
            }
        } catch (SQLException e) {
            // SQLException 처리
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new FoodUI2();
    }
}


