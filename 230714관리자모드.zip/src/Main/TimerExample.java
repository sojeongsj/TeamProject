package Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TimerExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Timer Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // 현재 화면
        JPanel currentPanel = new JPanel();
        JLabel currentLabel = new JLabel("Current Screen");
        currentPanel.add(currentLabel);
        frame.getContentPane().add(currentPanel);
        
        // 전환될 화면
        JPanel nextPanel = new JPanel();
        JLabel nextLabel = new JLabel("Next Screen");
        nextPanel.add(nextLabel);
        
        // Timer 객체 생성
        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 타이머 이벤트 발생 시, 화면 전환
                frame.getContentPane().removeAll();
                frame.getContentPane().add(nextPanel);
                frame.revalidate();
                frame.repaint();
            }
        });
        
        // 타이머 시작
        timer.start();

        frame.pack();
        frame.setVisible(true);
    }
}
