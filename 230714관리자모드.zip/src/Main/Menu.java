package Main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;


public class Menu {

	private JFrame mainjf;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu window = new Menu();
					window.mainjf.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}//main end

	/**
	 * Create the application.
	 */
	public Menu() {
		initialize();
	}//생성자 end	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		//Frame
		mainjf = new JFrame();
		mainjf.getContentPane().setBackground(new Color(255, 255, 255));
		mainjf.setBounds(100, 100, 665, 864);
		mainjf.setTitle("BURGER QUEEN");
		mainjf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainjf.getContentPane().setLayout(null);
		
		
		/////////////////////////////////////////////////////////
		
		
		//전체패널명 패널
		JPanel mainjp = new JPanel();
		mainjp.setBackground(new Color(255, 255, 255));
		mainjp.setBounds(56, 21, 532, 119);
		mainjf.getContentPane().add(mainjp);
		mainjp.setLayout(null);
				
		JLabel brandName = new JLabel("QUEEN's  MENU");
		brandName.setForeground(new Color(204, 0, 0));
		brandName.setBounds(126, 55, 296, 54);
		brandName.setFont(new Font("Bauhaus 93", Font.BOLD, 40));
		mainjp.add(brandName);
		
		
		////////////////////////////////////////////////////////////
		
		
		//주문하기, 장바구니 패널
		JPanel cartjp = new JPanel();
		cartjp.setBackground(new Color(255, 255, 255));
		cartjp.setBounds(72, 695, 509, 90);
		mainjf.getContentPane().add(cartjp);
		
		
		//주문하기 버튼
		JButton orderButton = new JButton("주문하기");
		orderButton.setBounds(70, 28, 152, 37);
		orderButton.setFont(new Font("-윤고딕330", Font.BOLD, 21));
		orderButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		cartjp.setLayout(null);
		cartjp.add(orderButton);
		
		
		//장바구니 버튼
		JButton cartButton = new JButton("장바구니");
		cartButton.setBounds(279, 29, 140, 35);
		cartButton.setFont(new Font("-윤고딕330", Font.BOLD, 21));
		cartButton.setVerticalAlignment(SwingConstants.TOP);
		cartjp.add(cartButton);
		
		
		////////////////////////////////////////////////////////////
		
		
		//버거,사이드,음료 탭 패널
		JTabbedPane tabbedPane = 
				new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setFont(new Font("-윤고딕350", Font.PLAIN, 13));
		tabbedPane.setBounds(72, 167, 496, 488);
		mainjf.getContentPane().add(tabbedPane);
		
		
		////////////////////////////////////////////////////////////
		
		
		//버거 패널
		JPanel burgerPanel = new JPanel();
		tabbedPane.addTab("버거", null, burgerPanel, null);
		burgerPanel.setLayout(null);
		
		
		//버거 스크롤 패널
		JScrollPane burgerScrollP = new JScrollPane();
		burgerScrollP.setBounds(29, 42, 460, 395);
		burgerPanel.add(burgerScrollP);
		
		JPanel bPanel = new JPanel();
		burgerScrollP.setViewportView(bPanel);
		bPanel.setLayout(new GridLayout(5, 2, 10, 10));
//		bPanel.setBorder(new LineBorder(Color.green));	//임시 패널 표시용
		
		//버거 버튼 반복문
		
		//이미지 파일 삽입을 위한 반복문 ex) "C:\\Users\\Administrator\\Desktop\\burger\\1.png"; 숫자만 증가
		String[] burgerbuttonimg = new String[10];
		String filepath = "./image/";
		for (int i = 0; i < burgerbuttonimg.length; i++) {
			String fileName = filepath + String.valueOf(i + 1) + ".png";
			burgerbuttonimg[i] = fileName;
		}
		
				
		int numbuttonburgers = 10;
		JButton[] burgerbutton = new JButton[numbuttonburgers];
		JPanel[] burgers = new JPanel[numbuttonburgers];
		String[] burgernames = {"불고기버거","더블불고기버거","새우버거","치즈버거","더블치즈버거","치킨버거","어니언치즈버거","아보카도버거","트리플패티버거","할라피뇨치킨버거"};
		JLabel[] bugerlabels = new JLabel[numbuttonburgers];
		 for (int i = 0; i < burgerbutton.length; i++) {
			 //상품 패널 생성
			 burgers[i] = new JPanel();
			 burgers[i].setLayout(new BorderLayout());
			 burgers[i].setSize(200,220);
			 
			 //버튼생성
			 burgerbutton[i] = new JButton();
			 
			 //이미지 크기조정
			 ImageIcon icon = new ImageIcon(burgerbuttonimg[i]);
			 Image img = icon.getImage();
			 img = img.getScaledInstance(180, 180, Image.SCALE_SMOOTH);
			 icon = new ImageIcon(img);
			 burgerbutton[i].setIcon(icon);			//이미지 크기는 150,130
			 burgers[i].add(burgerbutton[i],BorderLayout.NORTH);
			
			 //버거 이름 레이블
			 bugerlabels[i] = new JLabel(burgernames[i]);
			 bugerlabels[i].setFont(new Font("-윤고딕340", Font.PLAIN, 13));
			 bugerlabels[i].setVerticalAlignment(SwingConstants.TOP);
			 bugerlabels[i].setHorizontalAlignment(SwingConstants.CENTER);
		      
			 bugerlabels[i].setSize(180,20);		//레이블 크기
		     burgers[i].add(bugerlabels[i],BorderLayout.SOUTH);
		      
		     bPanel.add(burgers[i]);
			 
			 //버튼 이벤트
			 burgerbutton[i].addActionListener(new ActionListener() {
		         public void actionPerformed(ActionEvent e) {
		         }
		      });
		 }
		 
		
		
		//사이드 패널
		JPanel sidePanel = new JPanel();
		tabbedPane.addTab("사이드", null, sidePanel, null);
		sidePanel.setLayout(null);
		
		
		//사이드 스크롤 패널
		JScrollPane sideScrollP = new JScrollPane();
		sideScrollP.setBounds(29, 42, 434, 395);
		sidePanel.add(sideScrollP);
		
		JPanel sPanel = new JPanel();
		sideScrollP.setViewportView(sPanel);
		sPanel.setLayout(new GridLayout(0, 2, 10, 5));
		
		
		
		//음료 패널
		JPanel drinkPanel =  new JPanel();
		tabbedPane.addTab("음료", null, drinkPanel, null);	
		drinkPanel.setLayout(null);
		
		
		//음료 스크롤 패널
		JScrollPane drinkScrollP = new JScrollPane();
		drinkScrollP.setBounds(29, 42, 434, 395);
		drinkPanel.add(drinkScrollP);
		
		JPanel dPanel = new JPanel();
		drinkScrollP.setViewportView(dPanel);
		dPanel.setLayout(new GridLayout(0, 2, 10, 5));
		
		
		
		
	}//생성자 end
}//class end
