package kioskDAO;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FoodCount extends JFrame {
    private JTextField textField;
    private int value;

    public FoodCount() {
        setTitle("Text Field with Buttons");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // 패널 생성
        JPanel panel = new JPanel();

        // 초기 값 설정
        value = 0;

        // 텍스트 필드 생성
        textField = new JTextField(Integer.toString(value), 10);
        textField.setEditable(false);

        // "-" 버튼 생성
        JButton minusButton = new JButton("-");
        minusButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // "-" 버튼 클릭 시 값 감소 (0 미만으로 내려가지 않도록 제한)
                if (value > 0) {
                    value--;
                    textField.setText(Integer.toString(value));
                }
            }
        });

        // "+" 버튼 생성
        JButton plusButton = new JButton("+");
        plusButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // "+" 버튼 클릭 시 값 증가
                value++;
                textField.setText(Integer.toString(value));
            }
        });

        // "확인" 버튼 생성
        JButton confirmButton = new JButton("확인");
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // "확인" 버튼 클릭 시 텍스트 필드 안의 값 출력
                System.out.println("입력된 값: " + textField.getText());
                textField.setText("0");
                value=Integer.parseInt(textField.getText());
                setVisible(false);
            }
        });

        // 패널에 텍스트 필드와 버튼 추가
        panel.add(minusButton, BorderLayout.WEST);
        panel.add(textField, BorderLayout.CENTER);
        panel.add(plusButton, BorderLayout.EAST);
        panel.add(confirmButton, BorderLayout.SOUTH);

        // 프레임에 패널 추가
        add(panel);

        pack();
        setVisible(true);
    }
    
    public int getValue() {
        return value;
    }

    public static void main(String[] args) {
        new FoodCount();
    }
}
